package com.example.demo.dto

class FinalDataDto(
    val skuID: String,
    val description: String,
    val sainID: String
)