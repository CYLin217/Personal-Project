package com.example.demo.dto

data class PersonalProjectDto(
    val skuID: String,
    val description: String
)

